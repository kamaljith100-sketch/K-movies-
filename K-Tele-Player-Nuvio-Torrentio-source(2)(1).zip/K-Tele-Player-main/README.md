# K-Tele Player — Nuvio / Torrentio catalog integration

This source build adds a separate **Movies & Series Add-on** tile to the Media hub.

- Reads the Stremio-compatible catalog list from `https://catalog.nuvio.tv/manifest.json`.
- Loads the first catalog advertised by that manifest.
- Requests stream results from `https://torrentio.strem.fun/stream/{type}/{id}.json`.
- Plays direct HTTP(S) streams with the existing Media3 player.
- Sends info-hash torrent streams to the existing TorrentStream player.

## Build

Requires Android Studio / Android Gradle Plugin 8.7.3, Kotlin 1.9.25, JDK 17, and Android SDK 35.

From this directory, run:

```bash
gradle assembleDebug
```

The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes

- The catalog addon may change its manifest/catalog schema; this implementation uses the standard Stremio manifest, catalog, and stream response shapes.
- Torrent availability, playback compatibility, and speed depend on the returned source and peers.
- Only access and play content you are authorized to use. Torrent peers may be able to see your IP address.
